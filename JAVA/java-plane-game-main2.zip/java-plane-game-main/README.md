# java-plane-game

![game](https://user-images.githubusercontent.com/58245926/197395114-366277ed-61af-4952-abda-77e3d976d9b2.gif)
